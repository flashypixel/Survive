/* Survivor — complete build with weapon/ability system */
const loadingLabel=document.getElementById('loadingLabel');
const IMG_SRC={
  player:'assets/player.png',
  grunt:'assets/enemy_grunt.png',
  fast:'assets/enemy_fast.png',
  tank:'assets/enemy_tank.png',
  shooter:'assets/enemy_shooter.png',
  boss:'assets/enemy_boss.png',
  gem:'assets/gem.png',
  bullet:'assets/bullet.png',
  ebullet:'assets/enemy_bullet.png',
  ground:'assets/ground_tile.png',
  blade:'assets/blade.png',
  nova:'assets/nova_ring.png',
  w_blaster:'assets/weapon_gunner.png',
  w_orbit:'assets/weapon_reaper.png',
  w_nova:'assets/weapon_nova.png',
  w_boomerang:'assets/weapon_boomerang.png'
};
const IMG={};
let assetsReady=false, groundPattern=null;
function loadAssets(){
  const keys=Object.keys(IMG_SRC);
  return Promise.all(keys.map(k=>new Promise(res=>{
    const img=new Image();
    img.onload=()=>{ IMG[k]=img; res(); };
    img.onerror=()=>{ res(); }; // fail-soft: game still runs without a texture
    img.src=IMG_SRC[k];
  }))).then(()=>{
    assetsReady=true;
    if(IMG.ground) groundPattern=ctx.createPattern(IMG.ground,'repeat');
    document.getElementById('startBtn').disabled=false;
    if(loadingLabel) loadingLabel.classList.add('hidden');
  });
}

const canvas=document.getElementById('game');
const ctx=canvas.getContext('2d');
const hpEl=document.getElementById('hp'), levelEl=document.getElementById('level');
const xpEl=document.getElementById('xp'), timeEl=document.getElementById('time');
const hpFill=document.getElementById('hpFill'), xpFill=document.getElementById('xpFill');
const joystick=document.getElementById('joystick'), stick=document.getElementById('stick');
const startScreen=document.getElementById('startScreen'), levelUp=document.getElementById('levelUp');
const gameOver=document.getElementById('gameOver'), choices=document.getElementById('choices');
const pauseBtn=document.getElementById('pauseBtn'), muteBtn=document.getElementById('muteBtn');
const pausePanel=document.getElementById('pausePanel');
const bossWrap=document.getElementById('bossWrap'), bossFill=document.getElementById('bossFill');
const bestStart=document.getElementById('bestStart'), bestEnd=document.getElementById('bestEnd');
const weaponBar=document.getElementById('weaponBar');
const banner=document.getElementById('banner');

let W=innerWidth,H=innerHeight,dpr=1;
const ZOOM=0.70; /* <1 = zoomed out, more vision on mobile */
function resize(){
  dpr=Math.min(devicePixelRatio||1,2); W=innerWidth; H=innerHeight;
  canvas.width=W*dpr; canvas.height=H*dpr; canvas.style.width=W+'px'; canvas.style.height=H+'px';
  ctx.setTransform(dpr,0,0,dpr,0,0);
}
addEventListener('resize',resize); resize();

/* ---------- persistence ---------- */
const SAVE_KEY='survivor_best_v2';
function loadBest(){ try{return JSON.parse(localStorage.getItem(SAVE_KEY))||{time:0,level:1}}catch(e){return{time:0,level:1}} }
function saveBest(b){ try{localStorage.setItem(SAVE_KEY,JSON.stringify(b))}catch(e){} }
let best=loadBest();
function fmt(t){let m=Math.floor(t/60),s=Math.floor(t%60);return `${m}:${String(s).padStart(2,'0')}`}
function refreshBestLabels(){
  bestStart.textContent=`Best: ${fmt(best.time)} · Lv ${best.level}`;
  bestEnd.textContent=`Best: ${fmt(best.time)} · Lv ${best.level}`;
}
refreshBestLabels();

/* ---------- sound (synthesized, no assets needed) ---------- */
let muted=(localStorage.getItem('survivor_muted')==='1');
let actx=null;
function ensureAudio(){ if(!actx){ try{actx=new (window.AudioContext||window.webkitAudioContext)()}catch(e){} } }
function beep(freq,dur,type='sine',vol=.08,delay=0){
  if(muted||!actx)return;
  const t=actx.currentTime+delay;
  const o=actx.createOscillator(), g=actx.createGain();
  o.type=type; o.frequency.setValueAtTime(freq,t);
  g.gain.setValueAtTime(0,t); g.gain.linearRampToValueAtTime(vol,t+.01);
  g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  o.connect(g); g.connect(actx.destination);
  o.start(t); o.stop(t+dur+.02);
}
const sfx={
  shoot:()=>beep(720,.05,'square',.03),
  swing:()=>beep(340,.06,'triangle',.035),
  nova:()=>{beep(200,.18,'sine',.06,0);beep(300,.22,'sine',.05,.05)},
  hit:()=>beep(180,.07,'square',.05),
  pickup:()=>beep(1100,.05,'sine',.04),
  hurt:()=>beep(120,.15,'sawtooth',.08),
  levelup:()=>{beep(523,.1,'sine',.07,0);beep(659,.1,'sine',.07,.09);beep(784,.16,'sine',.08,.18)},
  bossWarn:()=>{beep(110,.3,'sawtooth',.09,0);beep(110,.3,'sawtooth',.09,.32)},
  death:()=>{beep(300,.2,'sawtooth',.08,0);beep(140,.4,'sawtooth',.08,.15)}
};
function vibrate(ms){ if(!muted && navigator.vibrate) try{navigator.vibrate(ms)}catch(e){} }
function updateMuteBtn(){ muteBtn.textContent = muted?'🔇':'🔊'; }
muteBtn.onclick=()=>{ muted=!muted; localStorage.setItem('survivor_muted',muted?'1':'0'); updateMuteBtn(); };
updateMuteBtn();

/* ---------- input ---------- */
const input={x:0,y:0};
let pointerId=null;
function setJoy(clientX,clientY){
  const r=joystick.getBoundingClientRect(), cx=r.left+r.width/2, cy=r.top+r.height/2;
  let dx=clientX-cx,dy=clientY-cy, max=r.width*.32, len=Math.hypot(dx,dy);
  if(len>max){dx=dx/len*max;dy=dy/len*max}
  stick.style.transform=`translate(${dx}px,${dy}px)`;
  input.x=dx/max; input.y=dy/max;
}
function resetJoy(){pointerId=null;input.x=input.y=0;stick.style.transform='translate(0,0)'}
joystick.addEventListener('pointerdown',e=>{pointerId=e.pointerId;joystick.setPointerCapture(pointerId);setJoy(e.clientX,e.clientY);ensureAudio()});
joystick.addEventListener('pointermove',e=>{if(e.pointerId===pointerId)setJoy(e.clientX,e.clientY)});
joystick.addEventListener('pointerup',resetJoy); joystick.addEventListener('pointercancel',resetJoy);

/* ---------- wake lock (keep screen on while playing) ---------- */
let wakeLock=null;
async function requestWake(){ try{ if('wakeLock' in navigator) wakeLock=await navigator.wakeLock.request('screen'); }catch(e){} }
document.addEventListener('visibilitychange',()=>{ if(document.visibilityState==='visible' && running && !paused) requestWake(); });
function releaseWake(){ if(wakeLock){ try{wakeLock.release()}catch(e){} wakeLock=null; } }

/* ---------- state ---------- */
let running=false,paused=false,last=0,gameTime=0,spawnTimer=0,bossTimer=110,bossActive=null;
let enemies=[],shots=[],eshots=[],gems=[],particles=[],popups=[],boomerangs=[],novaPulses=[];
let orbitAngle=0;
let nextId=1;
let shake=0;
let milestonesSeen=new Set();

const player={
  x:0,y:0,r:16,hp:100,maxHp:100,speed:180,
  pickup:70,xp:0,need:10,level:1,facing:0,hitFlash:0,regen:0,
  weapons:{}, mult:{power:1,cooldown:1,area:1}
};

/* ---------- pacing (tuned for longer, lighter-load mobile runs) ---------- */
const BOSS_INTERVAL=125;
const ENEMY_CAP=90;
const WMAX=4;
const WEAPON_DEFS={
  blaster:{
    name:'Blaster', desc:'Auto-fires at the nearest enemy.',
    dmg:[20,26,33,41,50], rate:[0.55,0.48,0.42,0.36,0.30], count:[1,1,2,2,3], pierce:[0,0,0,1,1],
    levelDesc:l=>`${l>=4?'Pierces, ':''}${WEAPON_DEFS.blaster.count[l-1]} shot${WEAPON_DEFS.blaster.count[l-1]>1?'s':''}, ${WEAPON_DEFS.blaster.dmg[l-1]} dmg`
  },
  orbit:{
    name:'Orbit Blades', desc:'Spinning blades that shred anything they touch.',
    dmg:[10,13,17,21,26], count:[2,3,3,4,5], radius:[62,66,72,80,88], spin:[2.1,2.3,2.5,2.8,3.1],
    levelDesc:l=>`${WEAPON_DEFS.orbit.count[l-1]} blades, ${WEAPON_DEFS.orbit.dmg[l-1]} dmg each`
  },
  nova:{
    name:'Nova Pulse', desc:'Periodic shockwave damages everything nearby.',
    dmg:[22,29,37,46,56], rate:[2.4,2.1,1.85,1.6,1.4], radius:[95,108,122,138,155],
    levelDesc:l=>`${WEAPON_DEFS.nova.dmg[l-1]} dmg, ${WEAPON_DEFS.nova.radius[l-1]}px radius`
  },
  boomerang:{
    name:'Boomerang', desc:'A blade that flies out, pierces, and comes back.',
    dmg:[16,21,27,34,42], rate:[1.4,1.2,1.05,0.9,0.78], range:[250,280,310,345,385], pierce:[3,4,5,6,8], speed:[430,450,470,490,515],
    levelDesc:l=>`${WEAPON_DEFS.boomerang.dmg[l-1]} dmg, pierces ${WEAPON_DEFS.boomerang.pierce[l-1]}`
  }
};
const WEAPON_ICON_COLOR={blaster:'#ffe66d',orbit:'#c8e8ff',nova:'#8fd6ff',boomerang:'#d7dde3'};
const WEAPON_ORDER=['blaster','orbit','nova','boomerang'];
let selectedWeapon='blaster';

const PASSIVES=[
 {name:"Power",desc:"+10% damage to all weapons",apply:()=>player.mult.power*=1.10},
 {name:"Haste",desc:"+8% attack speed to all weapons",apply:()=>player.mult.cooldown*=0.92},
 {name:"Amplify",desc:"+10% area (orbit & nova radius)",apply:()=>player.mult.area*=1.10},
 {name:"Swift",desc:"+15 movement speed",apply:()=>player.speed+=15},
 {name:"Vitality",desc:"+20 max HP and heal 20",apply:()=>{player.maxHp+=20;player.hp=Math.min(player.maxHp,player.hp+20)}},
 {name:"Magnet",desc:"+35 XP pickup range",apply:()=>player.pickup+=35},
 {name:"Regeneration",desc:"Slowly regen HP over time",apply:()=>player.regen+=0.6},
];

function buildChoicePool(){
  let pool=[];
  const owned=Object.keys(player.weapons);
  owned.forEach(k=>{
    const w=player.weapons[k], def=WEAPON_DEFS[k];
    if(w.level<def.dmg.length){
      pool.push({name:`${def.name} — Lv${w.level+1}`,desc:def.levelDesc(w.level+1),tag:'weapon',
        apply:()=>{w.level++}});
    }
  });
  if(owned.length<WMAX){
    Object.keys(WEAPON_DEFS).forEach(k=>{
      if(!player.weapons[k]) pool.push({name:'NEW: '+WEAPON_DEFS[k].name,desc:WEAPON_DEFS[k].desc,tag:'new',
        apply:()=>{player.weapons[k]={level:1,timer:0}}});
    });
  }
  PASSIVES.forEach(u=>pool.push({name:u.name,desc:u.desc,tag:'passive',apply:u.apply}));
  return pool;
}

/* ---------- enemy types ---------- */
const ENEMY_TYPES={
  grunt:{color:'#d94b4b',img:'grunt',rMul:1,hpMul:1,spdMul:1,dmgMul:1,ranged:false},
  fast:{color:'#f2c94c',img:'fast',rMul:.72,hpMul:.55,spdMul:1.9,dmgMul:.7,ranged:false},
  tank:{color:'#8e5bd9',img:'tank',rMul:1.55,hpMul:3.4,spdMul:.55,dmgMul:1.6,ranged:false},
  shooter:{color:'#f28c3c',img:'shooter',rMul:.9,hpMul:.8,spdMul:.75,dmgMul:.5,ranged:true},
};

function pickEnemyType(){
  const t=gameTime;
  const roll=Math.random();
  if(t>20 && roll<0.16) return 'shooter';
  if(t>35 && roll<0.30) return 'fast';
  if(t>50 && roll<0.42) return 'tank';
  return 'grunt';
}

const MILESTONES=[
  {t:60,msg:'1 minute survived — they\'re getting faster'},
  {t:180,msg:'3 minutes — stay sharp'},
  {t:300,msg:'5 minutes survived'},
  {t:600,msg:'10 minutes! The horde is relentless now'},
  {t:900,msg:'15 minutes — legendary run'},
];

function showBanner(text){
  banner.textContent=text;
  banner.classList.remove('hidden');
  banner.classList.add('show');
  clearTimeout(showBanner._t);
  showBanner._t=setTimeout(()=>{banner.classList.remove('show');},2600);
}

function resetGame(){
  Object.assign(player,{x:0,y:0,hp:100,maxHp:100,speed:180,pickup:70,xp:0,need:10,level:1,facing:0,hitFlash:0,regen:0});
  player.mult={power:1,cooldown:1,area:1};
  player.weapons={[selectedWeapon]:{level:1,timer:0}};
  enemies=[];shots=[];eshots=[];gems=[];particles=[];popups=[];boomerangs=[];novaPulses=[];nextId=1;
  gameTime=0;spawnTimer=0;bossTimer=BOSS_INTERVAL;bossActive=null;shake=0;orbitAngle=0;
  milestonesSeen=new Set();
  bossWrap.classList.add('hidden');
  updateHUD();
}
function startGame(){
  ensureAudio();
  resetGame();running=true;paused=false;
  startScreen.classList.add('hidden');gameOver.classList.add('hidden');levelUp.classList.add('hidden');pausePanel.classList.add('hidden');
  last=performance.now();requestAnimationFrame(loop);
  requestWake();
}
document.getElementById('startBtn').onclick=startGame;
document.getElementById('restartBtn').onclick=startGame;

function renderWeaponSelect(){
  const wrap=document.getElementById('weaponSelect');
  if(!wrap)return;
  wrap.innerHTML=WEAPON_ORDER.map(k=>{
    const def=WEAPON_DEFS[k];
    return `<button type="button" class="wcard${k===selectedWeapon?' selected':''}" data-w="${k}">
      <img src="${IMG_SRC['w_'+k]}" alt="">
      <span class="wc-name">${def.name}</span>
      <span class="wc-desc">${def.desc}</span>
    </button>`;
  }).join('');
  wrap.querySelectorAll('.wcard').forEach(btn=>{
    btn.onclick=()=>{
      selectedWeapon=btn.getAttribute('data-w');
      wrap.querySelectorAll('.wcard').forEach(b=>b.classList.toggle('selected',b===btn));
    };
  });
}
renderWeaponSelect();

pauseBtn.onclick=()=>{
  if(!running)return;
  paused=!paused;
  pausePanel.classList.toggle('hidden',!paused);
  if(!paused){ last=performance.now(); requestAnimationFrame(loop); }
};
document.getElementById('resumeBtn').onclick=()=>{ paused=false; pausePanel.classList.add('hidden'); last=performance.now(); requestAnimationFrame(loop); };
document.getElementById('quitBtn').onclick=()=>{
  paused=false; running=false; pausePanel.classList.add('hidden');
  startScreen.classList.remove('hidden');
  releaseWake();
};

function weaponBarHTML(){
  const owned=Object.keys(player.weapons);
  return owned.map(k=>{
    const w=player.weapons[k];
    return `<div class="wchip" style="--c:${WEAPON_ICON_COLOR[k]}"><span class="wname">${WEAPON_DEFS[k].name}</span><span class="wlvl">Lv${w.level}</span></div>`;
  }).join('');
}

function updateHUD(){
  hpEl.textContent=Math.max(0,Math.ceil(player.hp));levelEl.textContent=player.level;
  xpEl.textContent=`${player.xp}/${player.need}`;timeEl.textContent=fmt(gameTime);
  hpFill.style.width=(player.hp/player.maxHp*100)+'%';xpFill.style.width=(player.xp/player.need*100)+'%';
  if(bossActive){
    bossWrap.classList.remove('hidden');
    bossFill.style.width=Math.max(0,bossActive.hp/bossActive.maxHp*100)+'%';
  } else {
    bossWrap.classList.add('hidden');
  }
  if(weaponBar) weaponBar.innerHTML=weaponBarHTML();
}

function worldToScreen(x,y){
  const sx=shake?(Math.random()-.5)*shake:0, sy=shake?(Math.random()-.5)*shake:0;
  return{x:(x-player.x)*ZOOM+W/2+sx,y:(y-player.y)*ZOOM+H/2+sy};
}

function spawnEnemy(forceType){
  const a=Math.random()*Math.PI*2, dist=Math.max(W,H)/ZOOM*.65+80;
  const x=player.x+Math.cos(a)*dist,y=player.y+Math.sin(a)*dist;
  const scale=1+gameTime/170;
  const type=forceType||pickEnemyType();
  const cfg=ENEMY_TYPES[type];
  enemies.push({
    id:nextId++,x,y,type,
    r:(13+Math.random()*5)*cfg.rMul,
    hp:30*scale*cfg.hpMul,maxHp:30*scale*cfg.hpMul,
    speed:(45+Math.random()*25+gameTime*.045)*cfg.spdMul,
    damage:(8+gameTime*.022)*cfg.dmgMul,
    fireTimer:1+Math.random(),
    hitFlash:0, orbitCd:0
  });
}

function spawnBoss(){
  const a=Math.random()*Math.PI*2, dist=Math.max(W,H)/ZOOM*.65+120;
  const x=player.x+Math.cos(a)*dist,y=player.y+Math.sin(a)*dist;
  const cycle=Math.floor(gameTime/BOSS_INTERVAL);
  const hp=280*Math.pow(1.4,cycle);
  const b={id:nextId++,x,y,type:'boss',r:34,hp,maxHp:hp,speed:56+cycle*3,damage:20+cycle*3,fireTimer:1.4,boss:true,hitFlash:0,orbitCd:0};
  enemies.push(b); bossActive=b;
  sfx.bossWarn(); vibrate([80,60,80]);
  showBanner('⚠ BOSS INCOMING ⚠');
}

/* ---------- weapon firing logic ---------- */
function nearestEnemy(maxRange){
  let target=null,best=Infinity;
  for(const e of enemies){const d=Math.hypot(e.x-player.x,e.y-player.y);if((maxRange===undefined||d<maxRange)&&d<best){best=d;target=e}}
  return target;
}

function fireBlaster(level){
  const def=WEAPON_DEFS.blaster;
  const target=nearestEnemy(420);
  if(!target)return;
  const base=Math.atan2(target.y-player.y,target.x-player.x);
  player.facing=base;
  const count=def.count[level-1], spread=.14;
  const dmg=def.dmg[level-1]*player.mult.power;
  for(let i=0;i<count;i++){
    const off=(i-(count-1)/2)*spread;
    const a=base+off;
    shots.push({x:player.x,y:player.y,vx:Math.cos(a)*470,vy:Math.sin(a)*470,r:5,damage:dmg,life:1.5,pierceLeft:def.pierce[level-1]});
  }
  sfx.shoot();
}

function fireNova(level){
  const def=WEAPON_DEFS.nova;
  const radius=def.radius[level-1]*player.mult.area;
  const dmg=def.dmg[level-1]*player.mult.power;
  for(const e of enemies){
    const d=Math.hypot(e.x-player.x,e.y-player.y);
    if(d<radius+e.r) damageEnemy(e,dmg);
  }
  novaPulses.push({x:player.x,y:player.y,r:0,maxR:radius,life:0.4,t:0});
  sfx.nova(); vibrate(15);
}

function fireBoomerang(level){
  const def=WEAPON_DEFS.boomerang;
  const target=nearestEnemy(500);
  const a=target?Math.atan2(target.y-player.y,target.x-player.x):player.facing;
  const spd=def.speed[level-1];
  boomerangs.push({
    x:player.x,y:player.y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,
    ox:player.x,oy:player.y, dist:0, maxDist:def.range[level-1],
    phase:'out', pierceLeft:def.pierce[level-1], dmg:def.dmg[level-1]*player.mult.power,
    r:9, rot:0
  });
  sfx.swing();
}

function updateWeapons(dt){
  const w=player.weapons;
  if(w.blaster){ w.blaster.timer-=dt; if(w.blaster.timer<=0){ w.blaster.timer=WEAPON_DEFS.blaster.rate[w.blaster.level-1]*player.mult.cooldown; fireBlaster(w.blaster.level); } }
  if(w.nova){ w.nova.timer-=dt; if(w.nova.timer<=0){ w.nova.timer=WEAPON_DEFS.nova.rate[w.nova.level-1]*player.mult.cooldown; fireNova(w.nova.level); } }
  if(w.boomerang){ w.boomerang.timer-=dt; if(w.boomerang.timer<=0){ w.boomerang.timer=WEAPON_DEFS.boomerang.rate[w.boomerang.level-1]*player.mult.cooldown; fireBoomerang(w.boomerang.level); } }

  if(w.orbit){
    const def=WEAPON_DEFS.orbit, lvl=w.orbit.level;
    orbitAngle+=def.spin[lvl-1]*dt;
    const radius=def.radius[lvl-1]*player.mult.area;
    const count=def.count[lvl-1];
    const dmg=def.dmg[lvl-1]*player.mult.power;
    for(let i=0;i<count;i++){
      const a=orbitAngle+ (i/count)*Math.PI*2;
      const bx=player.x+Math.cos(a)*radius, by=player.y+Math.sin(a)*radius;
      for(const e of enemies){
        if(e.orbitCd>0) continue;
        const d=Math.hypot(e.x-bx,e.y-by);
        if(d<e.r+10){ damageEnemy(e,dmg); e.orbitCd=0.35; }
      }
    }
  }
  for(const e of enemies) if(e.orbitCd>0) e.orbitCd-=dt;

  // boomerangs
  for(let i=boomerangs.length-1;i>=0;i--){
    const b=boomerangs[i];
    b.rot+=dt*18;
    if(b.phase==='out'){
      b.x+=b.vx*dt; b.y+=b.vy*dt;
      b.dist=Math.hypot(b.x-b.ox,b.y-b.oy);
      if(b.dist>=b.maxDist) b.phase='back';
    } else {
      const a=Math.atan2(player.y-b.y,player.x-b.x);
      const spd=Math.hypot(b.vx,b.vy);
      b.vx=Math.cos(a)*spd; b.vy=Math.sin(a)*spd;
      b.x+=b.vx*dt; b.y+=b.vy*dt;
      if(Math.hypot(b.x-player.x,b.y-player.y)<20){ boomerangs.splice(i,1); continue; }
    }
    for(const e of enemies){
      if(b.pierceLeft<=0) break;
      const d=Math.hypot(e.x-b.x,e.y-b.y);
      if(d<e.r+b.r){ damageEnemy(e,b.dmg); b.pierceLeft--; addParticles(e.x,e.y,'#dfe6ea',3); }
    }
  }
  for(const p of novaPulses) p.t+=dt;
  novaPulses=novaPulses.filter(p=>p.t<p.life);
}

function enemyShoot(e){
  const a=Math.atan2(player.y-e.y,player.x-e.x);
  const spd=220;
  eshots.push({x:e.x,y:e.y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,r:5,damage:e.damage*1.1,life:2.4});
}

function dropXP(e){
  const n=e.boss?14:(1+(Math.random()<.12?1:0));
  for(let i=0;i<n;i++)gems.push({x:e.x+(Math.random()-.5)*24,y:e.y+(Math.random()-.5)*24,r:e.boss?8:6,value:e.boss?4:1});
}
function addParticles(x,y,color='#fff',n=5){
  for(let i=0;i<n;i++)particles.push({x,y,vx:(Math.random()-.5)*90,vy:(Math.random()-.5)*90,life:.32,color});
}
function addPopup(x,y,text,color='#fff'){
  popups.push({x,y,text,life:.6,color});
}
function gainXP(v){
  player.xp+=v;
  while(player.xp>=player.need){
    player.xp-=player.need;player.level++;player.need=Math.floor(player.need*1.3+4);
    showLevelUp();
  }
}
function showLevelUp(){
  paused=true; choices.innerHTML='';
  sfx.levelup(); vibrate(40);
  let pool=buildChoicePool().sort(()=>Math.random()-.5).slice(0,3);
  pool.forEach(u=>{
    const b=document.createElement('button');b.className='choice'+(u.tag==='new'?' choice-new':'');
    b.innerHTML=`<strong>${u.name}</strong><span>${u.desc}</span>`;
    b.onclick=()=>{u.apply();levelUp.classList.add('hidden');paused=false;last=performance.now();requestAnimationFrame(loop);updateHUD()};
    choices.appendChild(b);
  });
  levelUp.classList.remove('hidden');updateHUD();
}
function damageEnemy(e,dmg){
  e.hp-=dmg; e.hitFlash=.08;
  addParticles(e.x,e.y,'#ffe66d',3);
  addPopup(e.x,e.y-e.r-4,Math.round(dmg)+'', '#ffe66d');
  if(e.hp<=0 && !e.dead){
    e.dead=true;
    dropXP(e); addParticles(e.x,e.y,e.boss?'#ffb0b0':'#fff',e.boss?18:6);
    sfx.hit(); vibrate(e.boss?30:8);
    if(e.boss){ bossActive=null; shake=Math.min(shake+10,16); sfx.death(); }
  }
}
function damagePlayer(v){
  if(v<=0)return;
  player.hp-=v; player.hitFlash=.15; shake=Math.min(shake+3,14);
  if(player.hp<=0 && running){
    player.hp=0;running=false;paused=false;
    sfx.death(); vibrate([60,40,60,40,120]);
    if(gameTime>best.time || (gameTime===best.time&&player.level>best.level)){
      best={time:gameTime,level:player.level}; saveBest(best); refreshBestLabels();
    }
    document.getElementById('finalTime').textContent=fmt(gameTime);
    document.getElementById('finalLevel').textContent=player.level;
    gameOver.classList.remove('hidden');
    releaseWake();
  }
}

function update(dt){
  gameTime+=dt;
  for(const m of MILESTONES){ if(!milestonesSeen.has(m.t) && gameTime>=m.t){ milestonesSeen.add(m.t); showBanner(m.msg); } }
  if(player.regen>0) player.hp=Math.min(player.maxHp,player.hp+player.regen*dt);
  const len=Math.hypot(input.x,input.y);
  if(len>.05){player.x+=input.x*player.speed*dt;player.y+=input.y*player.speed*dt; player.facing=Math.atan2(input.y,input.x)}

  spawnTimer-=dt;
  const spawnRate=Math.max(.32,1.05-gameTime*.0032);
  if(spawnTimer<=0){
    spawnTimer=spawnRate;
    if(enemies.length<ENEMY_CAP){
      let count=gameTime>160?2:1;
      for(let i=0;i<count && enemies.length<ENEMY_CAP;i++)spawnEnemy();
    }
  }

  bossTimer-=dt;
  if(bossTimer<=0 && !bossActive){ bossTimer=BOSS_INTERVAL; spawnBoss(); }

  updateWeapons(dt);

  if(player.hitFlash>0) player.hitFlash-=dt;
  if(shake>0) shake=Math.max(0,shake-dt*30);

  for(const e of enemies){
    if(e.hitFlash>0) e.hitFlash-=dt;
    const cfg=ENEMY_TYPES[e.type]||{ranged:false};
    if(cfg.ranged){
      const d=Math.hypot(e.x-player.x,e.y-player.y)||1;
      const keep=220;
      if(d<keep-20){ e.x-=(player.x-e.x)/d*e.speed*dt; e.y-=(player.y-e.y)/d*e.speed*dt; }
      else if(d>keep+20){ e.x+=(player.x-e.x)/d*e.speed*dt; e.y+=(player.y-e.y)/d*e.speed*dt; }
      e.fireTimer-=dt;
      if(e.fireTimer<=0 && d<450){ e.fireTimer=1.6; enemyShoot(e); }
    } else {
      const dx=player.x-e.x,dy=player.y-e.y,d=Math.hypot(dx,dy)||1;
      e.x+=dx/d*e.speed*dt;e.y+=dy/d*e.speed*dt;
      if(d<e.r+player.r){damagePlayer(e.damage*dt)}
    }
    if(e.boss){
      const d=Math.hypot(e.x-player.x,e.y-player.y);
      if(d<e.r+player.r) damagePlayer(e.damage*dt*1.4);
    }
  }

  for(const s of shots){s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt}
  for(let i=shots.length-1;i>=0;i--)if(shots[i].life<=0)shots.splice(i,1);
  for(const s of eshots){s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt}
  for(let i=eshots.length-1;i>=0;i--){
    const s=eshots[i];
    const d=Math.hypot(s.x-player.x,s.y-player.y);
    if(d<s.r+player.r){ damagePlayer(s.damage); eshots.splice(i,1); sfx.hurt(); continue; }
    if(s.life<=0) eshots.splice(i,1);
  }

  for(let i=enemies.length-1;i>=0;i--){
    const e=enemies[i];
    for(let j=shots.length-1;j>=0;j--){
      const s=shots[j],d=Math.hypot(e.x-s.x,e.y-s.y);
      if(d<e.r+s.r){
        damageEnemy(e,s.damage);
        if(s.pierceLeft>0){ s.pierceLeft--; } else { shots.splice(j,1); }
        break;
      }
    }
    if(e.dead) enemies.splice(i,1);
  }

  for(let i=gems.length-1;i>=0;i--){
    const g=gems[i],d=Math.hypot(g.x-player.x,g.y-player.y);
    if(d<player.pickup){let a=Math.atan2(player.y-g.y,player.x-g.x),pull=Math.min(500,120+(player.pickup-d)*4);g.x+=Math.cos(a)*pull*dt;g.y+=Math.sin(a)*pull*dt}
    if(d<player.r+g.r+5){gainXP(g.value);gems.splice(i,1);sfx.pickup()}
  }
  for(const p of particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt}
  particles=particles.filter(p=>p.life>0);
  for(const p of popups){p.y-=30*dt;p.life-=dt}
  popups=popups.filter(p=>p.life>0);

  updateHUD();
}

function drawSprite(img, x, y, diameter, rotation, hitFlash){
  const half=diameter/2;
  ctx.save();
  ctx.translate(x,y);
  if(rotation!==undefined) ctx.rotate(rotation);
  if(hitFlash) ctx.filter='brightness(2.1) saturate(1.3)';
  ctx.drawImage(img,-half,-half,diameter,diameter);
  ctx.filter='none';
  ctx.restore();
}

function drawPlayer(){
  const p={x:W/2,y:H/2};
  if(IMG.player){
    drawSprite(IMG.player, p.x, p.y, player.r*2.6*ZOOM, player.facing, player.hitFlash>0);
  } else {
    ctx.save();ctx.translate(p.x,p.y);ctx.rotate(player.facing);
    ctx.beginPath();ctx.arc(0,0,player.r,0,Math.PI*2);
    ctx.fillStyle=player.hitFlash>0?'#ff8f8f':'#5fc7ff';ctx.fill();
    ctx.restore();
  }
}

function drawBackground(){
  if(groundPattern){
    ctx.save();
    ctx.scale(ZOOM,ZOOM);
    const ox=(-player.x)%128, oy=(-player.y)%128;
    ctx.translate(ox,oy);
    ctx.fillStyle=groundPattern;
    ctx.fillRect(-ox-4,-oy-4,W/ZOOM+8,H/ZOOM+8);
    ctx.restore();
  } else {
    ctx.fillStyle='#18221b';
    ctx.fillRect(0,0,W,H);
  }
  const grid=50*ZOOM,ox2=((W/2-player.x*ZOOM)%grid+grid)%grid,oy2=((H/2-player.y*ZOOM)%grid+grid)%grid;
  ctx.strokeStyle='rgba(255,255,255,.035)';ctx.lineWidth=1;
  for(let x=ox2;x<W;x+=grid){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
  for(let y=oy2;y<H;y+=grid){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
}

function drawWeaponFX(){
  // orbit blades
  if(player.weapons.orbit){
    const def=WEAPON_DEFS.orbit, lvl=player.weapons.orbit.level;
    const radius=def.radius[lvl-1]*player.mult.area*ZOOM;
    const count=def.count[lvl-1];
    const centerP=worldToScreen(player.x,player.y);
    for(let i=0;i<count;i++){
      const a=orbitAngle+(i/count)*Math.PI*2;
      const bx=centerP.x+Math.cos(a)*radius, by=centerP.y+Math.sin(a)*radius;
      if(IMG.blade) drawSprite(IMG.blade,bx,by,30*ZOOM,a+Math.PI/2,false);
      else{ctx.beginPath();ctx.arc(bx,by,7*ZOOM,0,Math.PI*2);ctx.fillStyle='#dfe6ea';ctx.fill()}
    }
  }
  // boomerangs
  for(const b of boomerangs){
    const p=worldToScreen(b.x,b.y);
    if(IMG.blade) drawSprite(IMG.blade,p.x,p.y,34*ZOOM,b.rot,false);
    else{ctx.beginPath();ctx.arc(p.x,p.y,b.r*ZOOM,0,Math.PI*2);ctx.fillStyle='#dfe6ea';ctx.fill()}
  }
  // nova pulses
  for(const n of novaPulses){
    const p=worldToScreen(n.x,n.y);
    const t=n.t/n.life;
    const r=n.maxR*Math.min(1,t*1.6)*ZOOM;
    const alpha=1-t;
    if(IMG.nova){
      ctx.save();ctx.globalAlpha=alpha;
      const d=r*2;
      ctx.drawImage(IMG.nova,p.x-d/2,p.y-d/2,d,d);
      ctx.restore();
    } else {
      ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);
      ctx.strokeStyle=`rgba(140,220,255,${alpha*.6})`;ctx.lineWidth=3;ctx.stroke();
    }
  }
}

function draw(){
  ctx.clearRect(0,0,W,H);
  drawBackground();

  for(const g of gems){
    const p=worldToScreen(g.x,g.y);
    if(IMG.gem) drawSprite(IMG.gem,p.x,p.y,g.r*2.6*ZOOM,0,false);
    else{ctx.beginPath();ctx.arc(p.x,p.y,g.r*ZOOM,0,Math.PI*2);ctx.fillStyle='#65d9ff';ctx.fill()}
  }
  for(const s of shots){
    const p=worldToScreen(s.x,s.y);
    const rot=Math.atan2(s.vy,s.vx);
    if(IMG.bullet) drawSprite(IMG.bullet,p.x,p.y,s.r*3.2*ZOOM,rot,false);
    else{ctx.beginPath();ctx.arc(p.x,p.y,s.r*ZOOM,0,Math.PI*2);ctx.fillStyle='#ffe66d';ctx.fill()}
  }
  for(const s of eshots){
    const p=worldToScreen(s.x,s.y);
    const rot=Math.atan2(s.vy,s.vx);
    if(IMG.ebullet) drawSprite(IMG.ebullet,p.x,p.y,s.r*3.2*ZOOM,rot,false);
    else{ctx.beginPath();ctx.arc(p.x,p.y,s.r*ZOOM,0,Math.PI*2);ctx.fillStyle='#ff6b6b';ctx.fill()}
  }

  drawWeaponFX();

  for(const e of enemies){
    const p=worldToScreen(e.x,e.y);
    const cfg=ENEMY_TYPES[e.type];
    const img=e.boss?IMG.boss:(cfg&&IMG[cfg.img]);
    const facing=Math.atan2(player.y-e.y,player.x-e.x);
    const er=e.r*ZOOM;
    if(img){
      ctx.save();
      const flip=Math.cos(facing)<0?-1:1;
      ctx.translate(p.x,p.y); ctx.scale(flip,1);
      if(e.hitFlash>0) ctx.filter='brightness(2.2)';
      const d=e.r*2.5*ZOOM;
      ctx.drawImage(img,-d/2,-d/2,d,d);
      ctx.filter='none';
      ctx.restore();
    } else {
      ctx.beginPath();ctx.arc(p.x,p.y,er,0,Math.PI*2);
      ctx.fillStyle=e.hitFlash>0?'#ffffff':(e.boss?'#b93b6b':(cfg?cfg.color:'#d94b4b'));ctx.fill();
    }
    ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(p.x-er,p.y-er-7,er*2,3);
    ctx.fillStyle='#72e06b';ctx.fillRect(p.x-er,p.y-er-7,er*2*Math.max(0,e.hp/e.maxHp),3);
  }
  for(const p of particles){const q=worldToScreen(p.x,p.y);ctx.globalAlpha=Math.max(0,p.life/.32);ctx.fillStyle=p.color;ctx.fillRect(q.x,q.y,3,3);ctx.globalAlpha=1}
  for(const p of popups){const q=worldToScreen(p.x,p.y);ctx.globalAlpha=Math.max(0,p.life/.6);ctx.fillStyle=p.color;ctx.font='bold 13px Arial';ctx.textAlign='center';ctx.fillText(p.text,q.x,q.y);ctx.globalAlpha=1}

  drawPlayer();
}

function loop(now){
  if(!running)return;
  const dt=Math.min(.033,(now-last)/1000);last=now;
  if(!paused){update(dt);draw();requestAnimationFrame(loop)}
}
document.getElementById('startBtn').disabled=true;
loadAssets().then(()=>draw());
draw();
