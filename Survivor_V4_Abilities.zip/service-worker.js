const CACHE = 'survivor-cache-v4';
const ASSETS = [
  './',
  './index.html',
  './style.css',
  './game.js',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-192.png',
  './icons/icon-maskable-512.png',
  './assets/player.png',
  './assets/enemy_grunt.png',
  './assets/enemy_fast.png',
  './assets/enemy_tank.png',
  './assets/enemy_shooter.png',
  './assets/enemy_boss.png',
  './assets/gem.png',
  './assets/bullet.png',
  './assets/enemy_bullet.png',
  './assets/ground_tile.png',
  './assets/blade.png',
  './assets/nova_ring.png',
  './assets/weapon_gunner.png',
  './assets/weapon_reaper.png',
  './assets/weapon_nova.png',
  './assets/weapon_boomerang.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then((cached) => {
      const fetchPromise = fetch(e.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE).then((cache) => cache.put(e.request, clone));
          }
          return networkResponse;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
