# Survivor

A top-down auto-battler survival game (2D, Brave Survivor-style): move with a joystick, your weapon fires automatically, dodge enemies, collect XP, and pick upgrades on level-up. Built with plain HTML/CSS/JS (Canvas) — no engine, no build step, runs anywhere.

## What's new in this build
- **Choose your weapon at the start screen**: pick Blaster, Orbit Blades, Nova Pulse, or Boomerang before you dive in — that's your starting weapon at Lv1.
- **Ability/weapon system** (Vampire-Survivors-style): on level-up you can pick up to 4 active weapons total, each leveling independently 1→5:
  - **Blaster** — auto-fires at the nearest enemy, gains extra shots and piercing.
  - **Orbit Blades** — spinning blades that continuously damage anything they touch.
  - **Nova Pulse** — a periodic shockwave that damages everything around you.
  - **Boomerang** — flies out, pierces multiple enemies, and returns to you.
  - Plus passive upgrades (Power, Haste, Amplify, Swift, Vitality, Magnet, Regeneration) that boost all your weapons at once.
- **Darker, grittier art pass**: muted, desaturated monsters with sunken glowing eyes and blood-spatter detail (rotten shambler, feral stalker, rotten brute, eye horror, and "The Butcher" boss), a worn/scarred human survivor, and a bloodied dirt ground texture — replacing the earlier bright cartoon look.
- **Wider camera / more visible area**: the view is zoomed out (~30% more world visible) so you can actually see incoming threats on a phone screen.
- **Longer, lighter-load runs**: slower spawn ramp, an enemy cap so it won't bog down on lower-end phones, gentler difficulty/boss scaling, and milestone banners at 1/3/5/10/15 minutes so long runs feel like they're going somewhere.
- Enemy variety, boss fights, screen shake, damage numbers, synthesized sound, haptics, pause menu, mute toggle, best-run tracking, and full offline PWA install — all still in from the previous build.

## Run it as a website first (fastest way to test)
1. Upload all files (keeping the folder structure — `icons/` included) to a static host: Replit, GitHub Pages, Netlify, Vercel, or Netlify Drop all work and are free.
2. Open the deployed link on your Android phone in Chrome.
3. Chrome should offer **"Add to Home screen" / "Install app"** — do that. It now opens full-screen, with its own icon, like a native app.

This alone gets you a real installable app icon on Android. If that's enough for you, you're done.

## Turning it into a real .apk / .aab (for sharing the file directly, or the Play Store)
Since you're developing from a phone, the easiest path is **PWABuilder** — it's a free website, no Android Studio required:

1. Deploy the site somewhere public (see step above — PWABuilder needs a live URL, not local files).
2. On your phone (or any device), go to **https://www.pwabuilder.com**.
3. Paste your site's URL and let it scan. It will read `manifest.json` and confirm the service worker.
4. Go to the **Android** package option and generate the package. It gives you a signed `.apk`/`.aab` you can download directly, or a project to build in Android Studio if you want more control.
5. Install the downloaded `.apk` on your phone (you may need to allow "install unknown apps" for your browser once), or upload the `.aab` to the Play Console if you want to publish it.

Alternative no-code wrappers if you'd rather not use PWABuilder: **Median.co** or **WebIntoApp** — both take a URL and hand back an `.apk`, similarly built for phone-only workflows.

## Files
```
index.html           — page structure, HUD, menus
style.css             — layout, mobile-safe-area handling
game.js               — all game logic
manifest.json         — PWA metadata (name, icons, display mode)
service-worker.js     — offline caching
icons/                — app icons (regular + maskable, 192px & 512px)
assets/               — sprite textures (player, enemies, gem, bullets, ground tile)
```

## About the textures
Every image in `assets/` is generated art (procedural shading, no photos/AI-image assets, no third-party sprites), so there's nothing to worry about license-wise. The game falls back to the original flat-shape rendering automatically if an image fails to load, so it never breaks visually even offline mid-download.

To swap in your own art later: replace any file in `assets/` with a same-named PNG (transparent background works best) — `game.js` doesn't need to change.

## Controls
- Touch/drag the joystick (bottom-left) to move.
- Your chosen weapon(s) fire/act automatically — melee weapons (Orbit Blades) need no aiming, ranged ones (Blaster, Boomerang) auto-target the nearest enemy.
- Collect XP gems; on level-up, choose a weapon upgrade, a new weapon, or a passive.
- Pause button (top-right, "II") pauses and opens a menu; speaker icon mutes sound.

## Ideas for where to take it next
- Swap the flat-color shapes for sprite art (the code is structured so you'd only need to touch the `draw()` and `drawPlayer()` functions).
- Add a second selectable character or starting weapon.
- Add meta-progression (persistent currency/unlocks between runs) using the same `localStorage` pattern already used for best score.
